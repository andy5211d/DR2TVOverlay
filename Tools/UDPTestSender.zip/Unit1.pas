//  Test UDP Sender to match DR UDP Monitor
//  For V4.n.n of the Monitor


unit Unit1;

interface

uses
  Winapi.Windows, Winapi.Messages,
  System.SysUtils, System.Classes,
  Vcl.Graphics, Vcl.Controls, Vcl.Forms, Vcl.Dialogs, Vcl.StdCtrls,
  IdUDPClient, IdStack, IdGlobal, IdExceptionCore, IdBaseComponent, IdComponent,
  IdUDPBase;

type
  TForm1 = class(TForm)
    IdUDPClient1: TIdUDPClient;
    MemoLog: TMemo;
    BtnGoodBurst: TButton;
    BtnIncomplete: TButton;
    BtnCorrupt: TButton;
    BtnUnknown: TButton;
    BtnShortBurst: TButton;
    BtnNoise: TButton;
    BtnInterleave: TButton;

    procedure FormCreate(Sender: TObject);
    procedure FormDestroy(Sender: TObject);

    procedure BtnGoodBurstClick(Sender: TObject);
    procedure BtnIncompleteClick(Sender: TObject);
    procedure BtnCorruptClick(Sender: TObject);
    procedure BtnUnknownClick(Sender: TObject);
    procedure BtnShortBurstClick(Sender: TObject);
    procedure BtnNoiseClick(Sender: TObject);
    procedure BtnInterleaveClick(Sender: TObject);

  private
    FDestIP: string;
    FSeq: UInt64;

    function GetPreferredPrivateIPv4: string;
    procedure Log(const S: string);
    procedure EnsureClientReady;
    procedure SendPacket(const Payload: string);
    function DumpLastBytes(const S: string; N: Integer): string;
    function Tail(const S: string; N: Integer): string;
    function MaxI(A, B: Integer): Integer;

    // Protocol-faithful builders
    function BuildUpdatePacket(const Origin: string; FaultMode: string; Seq: UInt64; Noise: string): string;
    function BuildRefereePacket(const Origin: string; FaultMode: string; Seq: UInt64; Noise: string): string;

    procedure SendBurst(const Kind, Origin: string; Count, GapMs: Integer;
      FaultMode: string = ''; NoiseMiddle: Boolean = False);
  public
  end;

var
  Form1: TForm1;

implementation

{$R *.dfm}

const
  DEST_PORT          = 58091;
  GAP_MS_DEFAULT     = 5;
  SHORT_BURST_GAP_MS = 120;

function TForm1.MaxI(A, B: Integer): Integer;
begin
  if A > B then Result := A else Result := B;
end;

function TForm1.Tail(const S: string; N: Integer): string;
begin
  if Length(S) <= N then
    Result := S
  else
    Result := Copy(S, Length(S) - N + 1, N);
end;

procedure TForm1.Log(const S: string);
begin
  MemoLog.Lines.Add(FormatDateTime('hh:nn:ss.zzz', Now) + '  ' + S);
end;

function TForm1.GetPreferredPrivateIPv4: string;
var
  L: TIdStackLocalAddressList;
  i: Integer;
  ip: string;

  function IsIPv4(const S: string): Boolean;
  begin
    Result := (S <> '') and (Pos(':', S) = 0);
  end;

  function StartsWith(const S, Prefix: string): Boolean;
  begin
    Result := SameText(Copy(S, 1, Length(Prefix)), Prefix);
  end;

  function Is172_16_to_31(const S: string): Boolean;
  var
    parts: TArray<string>;
    n: Integer;
  begin
    Result := False;
    if not StartsWith(S, '172.') then Exit;
    parts := S.Split(['.']);
    if Length(parts) < 2 then Exit;
    if TryStrToInt(parts[1], n) then
      Result := (n >= 16) and (n <= 31);
  end;

begin
  Result := '';

  L := TIdStackLocalAddressList.Create;
  try
    GStack.GetLocalAddressList(L);

    for i := 0 to L.Count - 1 do
    begin
      ip := L[i].IPAddress;
      if IsIPv4(ip) and (ip <> '127.0.0.1') and StartsWith(ip, '192.168.') then Exit(ip);
    end;

    for i := 0 to L.Count - 1 do
    begin
      ip := L[i].IPAddress;
      if IsIPv4(ip) and (ip <> '127.0.0.1') and StartsWith(ip, '10.') then Exit(ip);
    end;

    for i := 0 to L.Count - 1 do
    begin
      ip := L[i].IPAddress;
      if IsIPv4(ip) and (ip <> '127.0.0.1') and Is172_16_to_31(ip) then Exit(ip);
    end;

    for i := 0 to L.Count - 1 do
    begin
      ip := L[i].IPAddress;
      if IsIPv4(ip) and (ip <> '127.0.0.1') then Exit(ip);
    end;
  finally
    L.Free;
  end;
end;

procedure TForm1.EnsureClientReady;
begin
  if FDestIP = '' then
    FDestIP := GetPreferredPrivateIPv4;

  if FDestIP = '' then
    FDestIP := '127.0.0.1';

  IdUDPClient1.Host := FDestIP;
  IdUDPClient1.Port := DEST_PORT;

  // multi-instance safe
  IdUDPClient1.BoundIP := '';
  IdUDPClient1.BoundPort := 0;

  // unicast only
  IdUDPClient1.BroadcastEnabled := False;

  if not IdUDPClient1.Active then
    IdUDPClient1.Active := True;
end;

procedure TForm1.SendPacket(const Payload: string);
var
  caretPos: Integer;
  endsWithCaret: Boolean;
begin
  EnsureClientReady;

  caretPos := LastDelimiter('^', Payload);
  endsWithCaret := (caretPos > 0) and (caretPos = Length(Payload));

  try
    IdUDPClient1.Send(Payload);

    Log(Format(
    'Sent %d bytes ... caretPos=%d endsWithCaret=%s  LAST=[%s]',
    [Length(Payload), caretPos, BoolToStr(endsWithCaret, True), DumpLastBytes(Payload, 6)]));

  {
    Log(Format(
      'Sent %d bytes to %s:%d head=[%s] tail=[%s] caretPos=%d endsWithCaret=%s',
      [Length(Payload), IdUDPClient1.Host, IdUDPClient1.Port,
       Copy(Payload, 1, 70),
       Tail(Payload, 120),
       caretPos,
       BoolToStr(endsWithCaret, True)]
    ));
    }

    Caption := 'Last Sent ' + TimeToStr(Time) + ' -> ' + IdUDPClient1.Host + ':' + IntToStr(IdUDPClient1.Port);
  except
    on E: EIdSocketError do
    begin
      Log('SEND FAILED (EIdSocketError): #' + IntToStr(E.LastError) + ' ' + E.Message);
      Caption := 'Send failed: #' + IntToStr(E.LastError);
    end;
    on E: Exception do
    begin
      Log('SEND FAILED: ' + E.ClassName + ': ' + E.Message);
      Caption := 'Send failed';
    end;
  end;
end;

function TForm1.DumpLastBytes(const S: string; N: Integer): string;
var
  i, startIdx: Integer;
begin
  Result := '';
  if N <= 0 then Exit;

  startIdx := Length(S) - N + 1;
  if startIdx < 1 then startIdx := 1;

  for i := startIdx to Length(S) do
    Result := Result + Format('%s(%d) ', [S[i], Ord(S[i])]);
end;

// ---------------------
// UPDATE: EXACTLY 7 fields
// Field7 is '^' when complete.
// Fault rules:
//  - incomplete: field7 blank (no caret anywhere)
//  - corrupt: field7 = '^GARBAGE' (caret not last char)
//  - unknown: header = BOGUS, field7 = '^'
// ---------------------
function TForm1.BuildUpdatePacket(const Origin: string; FaultMode: string; Seq: UInt64; Noise: string): string;
var
  F: TArray<string>;
  Header: string;
begin
  SetLength(F, 7);

  if SameText(FaultMode, 'unknown') then
    Header := 'BOGUS'
  else
    Header := 'UPDATE';

  F[0] := Header;                 // 1
  F[1] := 'a';                    // 2
  F[2] := Origin;                 // 3
  F[3] := '1';                    // 4
  F[4] := '192.168.1.141';        // 5
  // keep realistic-ish path; doesn't matter to monitor except characters
  F[5] := 'C:\ProgramData\MDT\DiveRecorder\Xfer\Update.txt'; // 6

  if SameText(FaultMode, 'incomplete') then
    F[6] := ''                    // 7: no caret anywhere
  else if SameText(FaultMode, 'corrupt') then
    F[6] := '^GARBAGE'            // 7: caret present but not last char
  else
    F[6] := '^';                  // 7: caret-only terminator

  Result := String.Join('|', F);

  // Note: we do NOT add SEQ or identifier fields to UPDATE to keep it protocol-faithful.
  // If you want to track which update was sent, use the sender log (Seq is logged there).
end;

// ---------------------
// REFEREE: EXACTLY 74 fields
// Field9 = identifier, Field10 = SEQ or SEQ+corruption text
// Field74 is '^' when complete.
// Fault rules:
//  - incomplete: field74 blank AND no caret in field10
//  - corrupt: field74 blank AND field10 contains '^GARBAGE'
//  - unknown: header = BOGUS AND field74 '^'
// ---------------------
function TForm1.BuildRefereePacket(const Origin: string; FaultMode: string; Seq: UInt64; Noise: string): string;
var
  F: TArray<string>;
  i: Integer;
  Header, Field9, Field10: string;
  CaretLast: Boolean;
begin
  SetLength(F, 74);

  // Header
  if SameText(FaultMode, 'unknown') then
    Header := 'BOGUS'
  else
    Header := 'REFEREE';

  // Field 9 identifier
  if SameText(FaultMode, 'incomplete') then
    Field9 := 'TS_INCOMPLETE'
  else if SameText(FaultMode, 'corrupt') then
    Field9 := 'TS_CORRUPT'
  else if SameText(FaultMode, 'unknown') then
    Field9 := 'TS_UNKNOWN'
  else
    Field9 := 'TS_OK';

  // Field 10 SEQ (and corruption/noise inside field 10 to keep field count stable)
  if SameText(FaultMode, 'corrupt') then
    Field10 := 'SEQ=' + Seq.ToString + '^GARBAGE'
  else
    Field10 := 'SEQ=' + Seq.ToString;

  if Noise <> '' then
    Field10 := Field10 + ';' + Noise;

  // caret in last field?
  if SameText(FaultMode, 'incomplete') or SameText(FaultMode, 'corrupt') then
    CaretLast := False
  else
    CaretLast := True;

  // Fill first 8 fields similar to real traffic shape
  F[0] := Header;     // 1
  F[1] := 'a';        // 2
  F[2] := Origin;     // 3
  F[3] := '1';        // 4
  F[4] := 'False';    // 5
  F[5] := '6';        // 6
  F[6] := '1';        // 7
  F[7] := '2';        // 8

  // Fields 9 and 10
  F[8] := Field9;     // 9
  F[9] := Field10;    // 10

  // Empty placeholders for 11..73
  for i := 10 to 72 do
    F[i] := '';

  // Field 74
  if CaretLast then
    F[73] := '^'
  else
    F[73] := '';

  // Ensure incomplete has no caret anywhere
  if SameText(FaultMode, 'incomplete') then
    F[9] := StringReplace(F[9], '^', '', [rfReplaceAll]);

  Result := String.Join('|', F);
end;

procedure TForm1.SendBurst(const Kind, Origin: string; Count, GapMs: Integer;
  FaultMode: string; NoiseMiddle: Boolean);
var
  i: Integer;
  Payload, Noise: string;
begin
  for i := 1 to Count do
  begin
    Inc(FSeq);

    Noise := '';
    if NoiseMiddle and (i = 2) then
      Noise := 'NOISE=' + IntToStr(Random(100000));

    if SameText(Kind, 'UPDATE') then
      Payload := BuildUpdatePacket(Origin, FaultMode, FSeq, Noise)
    else
      Payload := BuildRefereePacket(Origin, FaultMode, FSeq, Noise);

    SendPacket(Payload);
    Sleep(GapMs);
  end;
end;

// ---------------- lifecycle ----------------

procedure TForm1.FormCreate(Sender: TObject);
begin
  Randomize;
  FSeq := 0;

  MemoLog.Clear;
  FDestIP := GetPreferredPrivateIPv4;
  if FDestIP = '' then FDestIP := '127.0.0.1';

  Log('Sender starting...');
  Log('Destination IP: ' + FDestIP);
  Log('Destination port: ' + IntToStr(DEST_PORT));
  Log('UPDATE is protocol-faithful: 7 fields (field7 caret)');
  Log('REFEREE is protocol-faithful: 74 fields (field74 caret), field9=id field10=SEQ');

  IdUDPClient1.Active := False;
  Caption := 'Sender ready -> ' + FDestIP + ':' + IntToStr(DEST_PORT);
end;

procedure TForm1.FormDestroy(Sender: TObject);
begin
  if IdUDPClient1.Active then
    IdUDPClient1.Active := False;
end;

// ---------------- Buttons ----------------

procedure TForm1.BtnGoodBurstClick(Sender: TObject);
begin
  Log('TEST: GOOD (UPDATE x3, REFEREE x3) Origin HP-A');
  SendBurst('UPDATE',  'HP-A', 3, GAP_MS_DEFAULT);
  SendBurst('REFEREE', 'HP-A', 3, GAP_MS_DEFAULT);
end;

procedure TForm1.BtnIncompleteClick(Sender: TObject);
begin
  Log('TEST: INCOMPLETE (no caret) Origin HP-A');
  SendBurst('UPDATE',  'HP-A', 1, 0, 'incomplete');
  SendBurst('REFEREE', 'HP-A', 1, 0, 'incomplete');
end;

procedure TForm1.BtnCorruptClick(Sender: TObject);
begin
  Log('TEST: CORRUPT (caret not last) Origin HP-A');
  SendBurst('UPDATE',  'HP-A', 1, 0, 'corrupt');
  SendBurst('REFEREE', 'HP-A', 1, 0, 'corrupt');
end;

procedure TForm1.BtnUnknownClick(Sender: TObject);
begin
  Log('TEST: UNKNOWN header (BOGUS) Origin HP-A');
  SendBurst('UPDATE',  'HP-A', 1, 0, 'unknown');
  SendBurst('REFEREE', 'HP-A', 1, 0, 'unknown');
end;

procedure TForm1.BtnShortBurstClick(Sender: TObject);
begin
  Log('TEST: SHORT BURST (2 then gap then 1) Origin HP-B');
  SendBurst('REFEREE', 'HP-B', 2, GAP_MS_DEFAULT);
  Sleep(SHORT_BURST_GAP_MS);
  SendBurst('REFEREE', 'HP-B', 1, 0);
end;

procedure TForm1.BtnNoiseClick(Sender: TObject);
begin
  Log('TEST: NOISE inside burst Origin HP-C');
  SendBurst('REFEREE', 'HP-C', 3, GAP_MS_DEFAULT, '', True);
end;

procedure TForm1.BtnInterleaveClick(Sender: TObject);
const
  Origins: array[0..3] of string = ('HP-A', 'HP-B', 'HP-C', 'HP-D');
var
  r, o: Integer;
begin
  Log('TEST: INTERLEAVE 4 origins x10 rounds');
  for r := 1 to 10 do
  begin
    for o := Low(Origins) to High(Origins) do
      SendBurst('REFEREE', Origins[o], 1, 0);
    Sleep(2);
  end;
end;

end.
