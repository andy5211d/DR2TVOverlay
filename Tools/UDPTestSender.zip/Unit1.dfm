object Form1: TForm1
  Left = 0
  Top = 0
  Caption = 'UDP Test Sender'
  ClientHeight = 407
  ClientWidth = 509
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -12
  Font.Name = 'Segoe UI'
  Font.Style = []
  TextHeight = 15
  object BtnGoodBurst: TButton
    Left = 24
    Top = 40
    Width = 75
    Height = 25
    Caption = 'Good Burst'
    TabOrder = 0
    OnClick = BtnGoodBurstClick
  end
  object BtnIncomplete: TButton
    Left = 24
    Top = 88
    Width = 75
    Height = 25
    Caption = 'Incomplete'
    TabOrder = 1
    OnClick = BtnIncompleteClick
  end
  object BtnCorrupt: TButton
    Left = 24
    Top = 136
    Width = 75
    Height = 25
    Caption = 'Corrupt'
    TabOrder = 2
    OnClick = BtnCorruptClick
  end
  object BtnUnknown: TButton
    Left = 24
    Top = 184
    Width = 75
    Height = 25
    Caption = 'Unknown'
    TabOrder = 3
    OnClick = BtnUnknownClick
  end
  object BtnShortBurst: TButton
    Left = 24
    Top = 232
    Width = 75
    Height = 25
    Caption = 'Short Burst'
    TabOrder = 4
    OnClick = BtnShortBurstClick
  end
  object BtnNoise: TButton
    Left = 24
    Top = 280
    Width = 75
    Height = 25
    Caption = 'Noise'
    TabOrder = 5
    OnClick = BtnNoiseClick
  end
  object BtnInterleave: TButton
    Left = 24
    Top = 328
    Width = 75
    Height = 25
    Caption = 'Interleave'
    TabOrder = 6
    OnClick = BtnInterleaveClick
  end
  object MemoLog: TMemo
    Left = 120
    Top = 41
    Width = 345
    Height = 312
    Lines.Strings = (
      'MemoLog')
    ScrollBars = ssVertical
    TabOrder = 7
  end
  object IdUDPClient1: TIdUDPClient
    Port = 0
    Left = 256
    Top = 48
  end
end
